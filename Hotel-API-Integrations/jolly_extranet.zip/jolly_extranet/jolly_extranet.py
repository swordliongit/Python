import ast
from datetime import datetime

import requests

from jolly_extranet_login import Login
from jolly_extranet_search import Search
from jolly_extranet_get_quota import Get_Quota
from jolly_extranet_update_quota import Update_Quota


def main():
    s = requests.Session()
    s = Login(s)

    # jollyextranet_search(s)

    # Get Rooms
    print(Get_Quota(s, HotelId="14056", date=datetime(2023, 10, 1)))

    # Update Quota ( Start, Stop )
    # Update_Quota(
    #     s,
    #     HotelRoomId="38315",
    #     Quota=5,
    #     QuotaDate=datetime(2023, 10, 31),
    #     Deadline=0,
    #     SaleStatus=0,
    # )


if __name__ == "__main__":
    main()
